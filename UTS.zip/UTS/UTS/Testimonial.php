       <!-- testimonial-area -->

             <!-- php code -->
            <?php 
              $testimonial_query = $dbcon->query("SELECT * FROM testimonials");
            ?>

            <section class="testimonial-area primary-bg pt-115 pb-115">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-xl-6 col-lg-8">
                            <div class="section-title text-center mb-70">
                                <span>testimonial</span>
                                <h2>happy customer quotes</h2>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-xl-9 col-lg-10">
                            <div class="testimonial-active">


                              <!-- php code-forech for testimonial -->
                              <?php foreach($testimonial_query as $row){ ?>

                                <div class="single-testimonial text-center">
                                    <div class="testi-avatar">
                                        <img style="width:100px;height: 100px;border-radius: 50%;" src="admin/image/customers/<?=$row['photo']?>" alt="img">
                                    </div>
                                    <div class="testi-content">
                                        <h4><span>“</span> <?=$row['customer_comment']?><span>”</span></h4>
                                        <div class="testi-avatar-info">
                                            <h5><?=$row['customer_name']?></h5>
                                            <span><?=$row['customer_desegnation']?></span>
                                        </div>
                                    </div>
                                </div>

                  <!-- php code-forech end -->
                                <?php } ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- testimonial-area-end -->