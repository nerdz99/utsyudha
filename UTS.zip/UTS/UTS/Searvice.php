<!-- Services-area -->

            <!-- php code for services area -->

            <?php

            $services_query = $dbcon->query("SELECT * FROM services ORDER BY id DESC LIMIT 6");

            ?>

            <section id="service" class="services-area pt-120 pb-50">
				<div class="container">
                    <div class="row justify-content-center">
                        <div class="col-xl-6 col-lg-8">
                            <div class="section-title text-center mb-70">
                                <span>WHAT WE DO</span>
                                <h2>Services and Solutions</h2>
                            </div>
                        </div>
                    </div>
					<div class="row">

              <!-- foreach code -->

              <?php
               foreach ($services_query as $service) {
                
              ?>

						<div class="col-lg-4 col-md-6">
							<div class="icon_box_01 wow fadeInLeft" data-wow-delay="0.2s">
                                <i class="<?=$service['icon']?>"></i>
								<h3><?=$service['title']?></h3>
								<p><?=$service['some_text']?></p>
							</div>
						</div>

            <!-- foreach end -->
          <?php } ?>
						
					</div>
				</div>
			</section>
            <!-- Services-area-end -->
